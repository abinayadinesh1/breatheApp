import SwiftUI
import PlaygroundSupport

struct Screen: View{
    
    @State var scale = false
    @State var rotate = false
    
    var body: some View{
        ZStack{
            Group{
                ZStack{
                    Circle().frame(width: 80, height: 80).foregroundColor(.blue).offset(y: -42)
                    Circle().frame(width: 80, height: 80).foregroundColor(.blue).offset(y: 42)
                    
                }
            }.opacity(1/3).rotationEffect(.degrees(120))
            Group{
                ZStack{
                    Circle().frame(width: 80, height: 80).foregroundColor(.green).offset(y: -42)
                    Circle().frame(width: 80, height: 80).foregroundColor(.green).offset(y: 42)
                    
                }
            }.opacity(1/4).rotationEffect(.degrees(60))
            Group{
                ZStack{
                    Circle().frame(width: 80, height: 80).foregroundColor(.pink).offset(y: -42)
                    Circle().frame(width: 80, height: 80).foregroundColor(.pink).offset(y: 42)
                    
                }
            }.opacity(1/2).rotationEffect(.degrees(180))
        }.rotationEffect(.degrees(rotate ? 180 : 0)).scaleEffect(scale ? 1: 1/8).animation(Animation.easeInOut.repeatForever(autoreverses:true).speed(1/8)).onAppear{
            self.rotate.toggle()
            self.scale.toggle()
        }
        
    }
    
}

PlaygroundPage.current.setLiveView(Screen())
